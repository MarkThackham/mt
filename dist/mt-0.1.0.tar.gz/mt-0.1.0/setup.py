from setuptools import setup, find_packages

setup(
    name="mt",  # Replace with your package name
    version="0.1.0",  #
)